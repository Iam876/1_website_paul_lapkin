import addClasses from './addClasses.js';
import removeClasses from './removeClasses.js';

export default { addClasses, removeClasses };
