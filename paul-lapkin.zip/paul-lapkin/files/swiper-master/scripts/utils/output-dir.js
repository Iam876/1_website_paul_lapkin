module.exports.outputDir = 'dist';
